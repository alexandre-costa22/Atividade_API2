const { Client } = require('pg');

const usuario = new Client({
    user: "postgres",
    password: "140502",
    host: "localhost",
    port: 5432,
    database: "teste"
  });

async function listar(){
    try{
    const usuarioConexao = new Client(usuario);
    const sql = "SELECT * FROM usuario";
    usuarioConexao.connect();
    
        const resultado = await usuarioConexao.query(sql);
        usuarioConexao.end();
        return resultado.rows;
    }
    catch(err){
        throw err;
    }
}

async function buscarPorId(id) {
    try {
        const conexaousuario = new Client(usuario);
        const sql = "SELECT * FROM usuario WHERE id=$1";
        const values = [id];
        conexaousuario.connect();
        const result = await conexaousuario.query(sql,values);
        conexaousuario.end();
        return result.rows[0];
    }
     catch(err){
        throw err;
    }

}

async function inserir(usuarioz) {
    const usuarioConexao = new Client(usuario);
    const sql = "INSERT INTO usuario(nome, email, senha, saldo) VALUES($1,$2,$3,$4) RETURNING *";
    const values = [usuarioz.nome, usuarioz.email, usuarioz.senha, usuarioz.saldo];
   usuarioConexao.connect();
    try {
        const resultado = await usuarioConexao.query(sql,values);
        //fechar a conexao
        await usuarioConexao.end();
        //trabalhar com o resultado.
        return resultado.rows[0];
    }
    catch(err){
        throw err;
    }
}

async function atualizar(id, usuario) {
    const conexaousuario = new Client(usuario);
    const sql = "UPDATE usuario SET nome=$1, email=$2, senha=$3, saldo=$4 WHERE id=$5 ";
    const values = [usuario.nome, usuario.email, usuario.senha, usuario.saldo, id];
    conexaousuario.connect();
    try {
        const resultado = await conexaousuario.query(sql,values);
        //fechar a conexao
        conexaousuario.end();
        //trabalhar com o resultado.
        return resultado.rows[0];
    }
    catch(err){
        throw err;
    }
}

async function deletar(id) {
    try {
    const checkIdSql = `SELECT id FROM usuario WHERE id = $1`;
    const checkIdValues = [getId];
    const checkIdResult = await usuario.query(checkIdSql, checkIdValues);
    const existingId = checkIdResult.rows.length > 0;

    if (!existingId) {
      res.status(404).send("Nenhum resultado encontrado para o ID fornecido");
      return;
    }

    const usuarioConexao = new Client(usuario);
    const sql = `DELETE FROM usuario WHERE id = $1`;
    const values = [id];
    usuarioConexao.connect();
  
        const resultado = await usuarioConexao.query(sql,values);
        //fechar a conexao
        usuarioConexao.end();
        //trabalhar com o resultado.
        return resultado.rows[0];
    }
    catch(err){
        throw err;
    }
}

module.exports = { 
    listar, buscarPorId, inserir, atualizar, deletar
}