const express = require("express");
const clienteController = require("../controllers/usuarioController")

const router = express.Router();

//api/clientes
router.get('/all',clienteController.listar)
router.get('/:id', clienteController.buscarPorId)
router.post('/post',  clienteController.inserir)
router.put('/:id', clienteController.atualizar)
router.delete('/:id', clienteController.deletar)

module.exports = router;