// app.js
const express = require('express');
const armasRoutes = require('./routes/armaRoutes');
const usuarioRota = require('./routes/usuarioRoutes')
const app = express();
const cors = require('cors');

app.use(express.json());

app.use(cors());


app.use('/armas', armasRoutes); 

app.use("/usuarios", usuarioRota);

app.listen(8082, () => {
  console.log('Servidor iniciado na porta 8082');
});
