
import icon from "..//../imagens/Merc.png"
import styled from 'styled-components'
import "./Texto.css"


const TextoContainer = styled.section`

position: absolute;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
width: 700px;
height: 500px;
background-color: rgb(22, 22, 22);
border-radius: 30px;
display: flex;
justify-content: center;
align-items: center;
box-shadow: 15px 15px 15px 15px rgba(0, 0, 0, 0.2);
margin-top: 15px;
}

.texto {
color: white;
text-align: center;
padding: 20px;
font-size: 25px


`

function Texto(){
    return(
        <TextoContainer>
            <p className ='texto'>Olá estranho, seu revendedor de armas favorito esta de volta!
            Estou desenvolvenndo esta Api para Compra/Venda de armas de forma Online.
            No momento você podera olhar as armas listadas no "Catalogo", Listar para venda 
            suas armas em "Vender", e você pode fazer um pré cadastro para quando a Api ficar completa!!!
            </p>
            <img src={icon} alt="" className='imgIcon'></img>
        </TextoContainer>
    )
}


export default Texto;