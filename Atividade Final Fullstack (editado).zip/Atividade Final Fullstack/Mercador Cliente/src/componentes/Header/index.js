import { Link } from 'react-router-dom'
import Logo from '../Logo'
import OpcoesHeader from '../OpcoesHeader'
import styled from 'styled-components'


const HeaderContainer = styled.header`
    background-color: rgb(22, 22, 22);
    display: flex;
    justify-content: center;
    font-family: 'Residente_Evil';
    color: white;    
    
`

function Header() {
    return (
        <HeaderContainer>
            <Link to="/">
                <Logo/>
            </Link>
            <OpcoesHeader/>
        </HeaderContainer>
    )
}

export default Header