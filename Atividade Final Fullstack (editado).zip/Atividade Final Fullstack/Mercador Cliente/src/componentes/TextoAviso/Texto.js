
import icon from "..//../imagens/icons8-warning-96.png"
import styled from 'styled-components'


const TextoContainer = styled.section`

position: absolute;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
width: 700px;
height: 500px;
background-color: rgb(22, 22, 22);
border-radius: 30px;
display: flex;
justify-content: center;
align-items: center;
box-shadow: 15px 15px 15px 15px rgba(0, 0, 0, 0.2);
margin-top: 15px;
flex-direction: column
}

.texto {
color: white;
text-align: center;
padding: 20px;
font-size: 30px



`

function TextoAviso(){
    return(
        <TextoContainer>
            <p className ='texto'>Ola estranho, ainda estamos trabalhando nesta area!
            </p>
            <img src={icon} alt="" className='imgIcon'></img>
        </TextoContainer>
    )
}


export default TextoAviso;