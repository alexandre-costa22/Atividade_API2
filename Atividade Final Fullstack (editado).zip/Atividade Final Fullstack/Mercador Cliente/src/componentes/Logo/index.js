import logo from '../../imagens/loja-de-armas.png'
import styled from 'styled-components'
import "./Logo.css"

const LogoContainer = styled.div`
    width: 100px;
    color: white;
    display: flex;
    margin: 15px;
    margin-right: 50px;
`

const LogoImage = styled.img`
    height: 100px;
    maring: 10px;

   
`


function Logo() {
    return (
        <LogoContainer>
            <LogoImage
                src={logo}
                alt='logo' 
            />
           <p><strong className='NomeLogo'>Loja do Mercador</strong></p>
       </LogoContainer>
    )
}

export default Logo