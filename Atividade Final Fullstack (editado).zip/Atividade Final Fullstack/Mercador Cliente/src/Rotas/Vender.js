
import styled from 'styled-components'
import "../Fonte.css"
import TextoAviso from '../componentes/TextoAviso/Texto';

const VendaContainer = styled.div`
    width: 100vw;
    height: 100vh;

    background-image: linear-gradient(90deg, #020202 35%, #2e203d);
    
`

function Vender() {
  return (
    <VendaContainer>
      <TextoAviso />
    </VendaContainer>
  );
}

export default Vender;
