
import styled from 'styled-components'
import "../Fonte.css"
import TextoAviso from '../componentes/TextoAviso/Texto';


const CadastroContainer = styled.div`
    width: 100vw;
    height: 100vh;

    background-image: linear-gradient(90deg, #020202 35%, #2e203d);
    
`

function Cadastro() {
  return (
    <CadastroContainer>
      <TextoAviso />
    </CadastroContainer>
  );
}

export default Cadastro;
