import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import TextoAviso from '../componentes/TextoAviso/Texto';
import { Client } from 'pg';

const CatalogoContainer = styled.div`
  width: 100vw;
  height: 100vh;
  background-image: linear-gradient(90deg, #020202 35%, #2e203d);
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
`;

const ArmaCard = styled.div`
  background-color: #ffffff;
  padding: 20px;
  margin: 10px;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
  display: flex;
  flex-direction: column;
  max-width: 300px;
  min-width: 250px;
`;

const ArmaImage = styled.img`
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: 8px;
  margin-bottom: 10px;
`;

function Catalogo() {
  const [armas, setArmas] = useState([]);

  useEffect(() => {
    // Configuração de conexão ao banco de dados
    const dbConfig = {
      user: "postgres",
      password: "postgres",
      host: "localhost",
      port: 5432,
      database: "teste",
    };

    // Criar cliente para conexão ao banco de dados
    const client = new Client(dbConfig);

    // Função para conectar e buscar os dados no banco de dados
    async function fetchData() {
      try {
        const response = await fetch('http://localhost:8082/armas/all'); // Rota para obter todas as armas
        const data = await response.json(); // Processar os dados como JSON
        setArmas(data);
      } catch (error) {
        console.error('Erro ao buscar dados:', error);
      }
    }
  
    // Chamada da função para buscar os dados
    fetchData();
  }, []);

  return (
    <CatalogoContainer>
      <TextoAviso />
      {armas.map((arma) => (
        <ArmaCard key={arma.id}>
          <ArmaImage src={`URL_DA_IMAGEM_DA_ARMA/${arma.id}.jpg`} alt={arma.nome} />
          <strong>{arma.nome}</strong>
          <p>Dano: {arma.dano}</p>
          <p>Valor: {arma.valor}</p>
        </ArmaCard>
      ))}
    </CatalogoContainer>
  );
}

export default Catalogo;
