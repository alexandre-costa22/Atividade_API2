const path = require('path');

module.exports = {
  // Restante da configuração do webpack...

  resolve: {
    fallback: {
      stream : false
    }
  }
}